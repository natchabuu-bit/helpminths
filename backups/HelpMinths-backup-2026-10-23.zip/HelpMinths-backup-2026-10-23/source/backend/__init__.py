"""HelpMinths image analysis API."""
