/* Replaced with the complete, integrity-checked static file list by the Vite build. */
const BUILD_VERSION = "cedf0532051c05bf";
const PRECACHE_ASSETS = [{"url":"/assets/Atlas-BH_SLXRj.js","integrity":"sha256-gmsKxfWvHbER9nZAJ4WzdXbMz2HcHUw+f/kyTm2SU0g="},{"url":"/assets/Atlas-DfG1qwHk.css","integrity":"sha256-LGQcY6XP94oSai5jgGuGYkIAG1CVduaOeaMz7LGg7dk="},{"url":"/assets/index-D5iLiozK.js","integrity":"sha256-lMgwBOxjaBMPQJl1z8Fe9PGwfa8KJetl3tsnE+kLQig="},{"url":"/assets/index-lWxtuXOh.css","integrity":"sha256-wdjZESo6lTb9LlTZSeFDimTY2prRft4pm0Icku15/aM="},{"url":"/assets/inter-cyrillic-ext-wght-normal-BOeWTOD4.woff2","integrity":"sha256-yhVwYzOaxK1BjyFPOr/tEZsHmKtNN3OGzlyeWnpDXr0="},{"url":"/assets/inter-cyrillic-wght-normal-DqGufNeO.woff2","integrity":"sha256-cdXuk8wenx1SCjqLZkVt4Yx4edjfCdV/zS6v91/vAHU="},{"url":"/assets/inter-greek-ext-wght-normal-DlzME5K_.woff2","integrity":"sha256-bp4CCiX5tW1BjywIWx08CXJaTaI/5pOltGMGRgZzIZA="},{"url":"/assets/inter-greek-wght-normal-CkhJZR-_.woff2","integrity":"sha256-G+NEjikvvwX/4Xb+HkPxNQE9ULHn0yStGlWPYj07tvY="},{"url":"/assets/inter-latin-ext-wght-normal-DO1Apj_S.woff2","integrity":"sha256-NLnFBMq3pz43t0Y0OkSRMuVs97VIGvLLgdx03P8lyVY="},{"url":"/assets/inter-latin-wght-normal-Dx4kXJAl.woff2","integrity":"sha256-MQDndehhbNJhG+7PojpCY9cDdYZ4m0PwNSNqLm+9TGI="},{"url":"/assets/inter-vietnamese-wght-normal-CBcvBZtf.woff2","integrity":"sha256-XGb54H6QxtSsSSLMaNYN4mwXsYWOZ3+15gP845UrP/I="},{"url":"/assets/noto-sans-thai-latin-ext-wght-normal-DH1q_yQ5.woff2","integrity":"sha256-SZKd6zr6P+o3sZ/dFIiJ7xmz5EqEUrE1aK8Imn1duTQ="},{"url":"/assets/noto-sans-thai-latin-wght-normal-Bi3VDbYN.woff2","integrity":"sha256-GmbyaMjXZXWAeXkwnLusOv97YZGfWeoZ/cgh2S+0B/M="},{"url":"/assets/noto-sans-thai-thai-wght-normal-CtQSZ1tK.woff2","integrity":"sha256-H1oXNkG7yzyk+wqYaFi2sH+M1d0u1hI2tAVIx6PHKS8="},{"url":"/atlas/photos/LICENSE-Buckelew.txt","integrity":"sha256-M8lmq8YlW3GAekqdYd5JNxU6+PrmbUByHFFIJR0ezHA="},{"url":"/atlas/photos/ascaris-embryonated-buckelew.jpg","integrity":"sha256-nDPMQgtULl83kGeZh2SQmlRZ9VqOAjuXSvl5cYYgJx4="},{"url":"/atlas/photos/ascaris-fertilized-unfertilized-buckelew.jpg","integrity":"sha256-dwLM7zPHyfjeM7SeMh7YZ3VzpEi2H5e56FzNEyIBqBM="},{"url":"/atlas/photos/enterobius-buckelew.jpg","integrity":"sha256-+dkJuCiKtImhg+dM9TR7XLxH6zpHVoHT5qsqPQxRg3k="},{"url":"/atlas/photos/fasciolopsis-buski-buckelew.jpg","integrity":"sha256-5uUkxEBlp9oxmCu9mGWNKm/1ACH4k6VyaaI+sqayIGA="},{"url":"/atlas/photos/hookworm-buckelew.jpg","integrity":"sha256-oBg7K1atQQlu2X94RNvweW0+zyJzLDHj/YAce7eqDpE="},{"url":"/atlas/photos/hymenolepis-diminuta-buckelew.jpg","integrity":"sha256-BeUitJhVKs1KiBcDPSrOBGEo2hmkWBF5in9SVjVHmZg="},{"url":"/atlas/photos/hymenolepis-nana-buckelew.jpg","integrity":"sha256-zUQmikPi7MMvoE1k8G4Q9VlufmrlFuqU8v9WRDpxvU4="},{"url":"/atlas/photos/strongyloides-rhabditiform-buckelew.jpg","integrity":"sha256-R3ZU2NALo44hZor4vuzahxxOw6jtdhrRox1UUt9Rvew="},{"url":"/atlas/photos/strongyloides-rhabditiform-stained-buckelew.jpg","integrity":"sha256-AuI/AnMg4DQJZINakK0mt0fSYxAiEbuucvBapybQPH0="},{"url":"/atlas/photos/taenia-buckelew.jpg","integrity":"sha256-IWpsaKKrATBbIq2F2vKlEMJM662CxtUSyUG9CHZ+ZWE="},{"url":"/atlas/photos/trichuris-buckelew.jpg","integrity":"sha256-rKhxnfYc1Y5C3PduQOG+l7CxCOAxKPrhI1CUrBk8+zk="},{"url":"/favicon.svg","integrity":"sha256-oxToBB9Ec/ONnsUbVX52aEAO0DRHkmoem/Z9//Ojueo="},{"url":"/icons/apple-touch-icon.png","integrity":"sha256-7abM608vLCG26sEEFbHfvbEfKllF07kqAR6ctV5lDnY="},{"url":"/icons/icon-192.png","integrity":"sha256-q6ZJaChgJBjqbj0KUGDlyOqrWtou7XLzA9SSW+TWs/w="},{"url":"/icons/icon-512.png","integrity":"sha256-we/5Ob6vyd8fTyUr92P6Te4K+ylkQ556RABb9s/1S1k="},{"url":"/icons/icon-maskable-512.png","integrity":"sha256-pW/RIVNkFjBZMRHE76J8z4VsUeXR1IoR4AATN0/Tcso="},{"url":"/index.html","integrity":"sha256-futigOtta6tZj46cVRXJziM/QPnxC1jOr0w9ytntQug="},{"url":"/manifest.webmanifest","integrity":"sha256-YgCf0K24wri4f2sK+B8Eku3WYxRXB3vudWXBQ6GrNxI="}];
const CACHE_NAME = `helpminths-static-${BUILD_VERSION}`;
const ASSETS_BY_PATH = new Map(PRECACHE_ASSETS.map(asset => [asset.url, asset]));

function expectedContentType(url, contentType) {
  const extension = url.split('.').pop().toLowerCase();
  const type = (contentType || '').split(';')[0].trim().toLowerCase();
  const known = {
    html: ['text/html'],
    js: ['application/javascript', 'text/javascript'],
    css: ['text/css'],
    json: ['application/json'],
    webmanifest: ['application/manifest+json', 'application/json'],
    svg: ['image/svg+xml'],
    png: ['image/png'],
    jpg: ['image/jpeg'],
    jpeg: ['image/jpeg'],
    webp: ['image/webp'],
    ico: ['image/vnd.microsoft.icon', 'image/x-icon'],
    woff2: ['font/woff2', 'application/font-woff2'],
    woff: ['font/woff', 'application/font-woff'],
    ttf: ['font/ttf', 'application/x-font-ttf'],
    otf: ['font/otf', 'application/x-font-opentype'],
  };
  return known[extension] ? known[extension].includes(type) : type !== 'text/html';
}

async function fetchAsset(asset) {
  const response = await fetch(new Request(asset.url, {
    cache: 'reload',
    credentials: 'same-origin',
    mode: 'same-origin',
    redirect: 'error',
    integrity: asset.integrity,
  }));
  if (response.status !== 200 || !expectedContentType(asset.url, response.headers.get('content-type'))) {
    throw new Error('Static asset failed validation');
  }
  return response;
}

async function installAssets() {
  const cache = await caches.open(CACHE_NAME);
  // Await every transfer before declaring readiness or deleting an incomplete cache.
  const outcomes = await Promise.allSettled(PRECACHE_ASSETS.map(async asset => {
    await cache.put(asset.url, await fetchAsset(asset));
  }));
  if (outcomes.some(outcome => outcome.status === 'rejected')) {
    await caches.delete(CACHE_NAME);
    throw new Error('The complete offline app could not be downloaded');
  }
}

self.addEventListener('install', event => {
  event.waitUntil(installAssets());
  // Updates wait for existing tabs to close. Never replace their active worker.
});

self.addEventListener('activate', event => {
  // Keep previous version caches: open tabs may still reference their lazy chunks.
  event.waitUntil(self.clients.claim());
});

self.addEventListener('message', event => {
  if (event.data?.type !== 'HELPMINTHS_OFFLINE_STATUS' || !event.ports[0]) return;
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const complete = await Promise.all(PRECACHE_ASSETS.map(asset => cache.match(asset.url)));
    event.ports[0].postMessage({
      ready: complete.every(Boolean),
      version: BUILD_VERSION,
      total: PRECACHE_ASSETS.length,
    });
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.protocol !== self.location.protocol) return;
  // Medical images/results and every API request always bypass the static cache.
  if (url.pathname === '/api' || url.pathname.startsWith('/api/')) return;
  const pathname = request.mode === 'navigate' && (url.pathname === '/' || url.pathname === '/index.html')
    ? '/index.html'
    : url.pathname;
  const asset = ASSETS_BY_PATH.get(pathname);
  if (!asset) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(asset.url);
    if (cached) return cached;
    // Recover evicted static files only when their build integrity still matches.
    const response = await fetchAsset(asset);
    await cache.put(asset.url, response.clone());
    return response;
  })());
});
